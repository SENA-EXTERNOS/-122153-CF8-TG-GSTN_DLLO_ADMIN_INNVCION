function ExecuteScript(strId)
{
  switch (strId)
  {
      case "61QdHQcRPpo":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

